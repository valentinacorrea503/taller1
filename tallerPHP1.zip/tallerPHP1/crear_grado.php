<?php


    include "conexion.php";

if(!empty($_POST)){
    $alert='';
    if( empty($_POST['grado'])  ||  empty($_POST['grupo']))  
    {
    $alert='<p class="msg_error"> todos los campos son obligatorios.</p>';

    }else{
    

     
        $grado = $_POST['grado'];
        $grupo = $_POST['grupo'];
       
        
     
     
    $query = mysqli_query($conection,"SELECT * FROM grado WHERE grado = '$grado' && grupo = '$grupo' && estatus = 1" );
        
        $result = mysqli_fetch_array($query);

        if($result > 0){
            $alert ='<p class="msg_error">El  GRADO-GRUPO YA EXISTE  .</p>';

    }else{

            $query_insert = mysqli_query($conection, "INSERT INTO grado(grado,grupo)
            VALUES('$grado','$grupo')");
        if($query_insert){
             
            $alert ='<p class="msg_save">grado creado correctamente.</p>';
        }else{
            $alert ='<p class="msg_error">Error al crear el grado.</p>';
        }
    }
}
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "index.php"?>
    <title>Registro Grado</title>
</head>
<body>

    <section id="container">
    
<div class="form_register"> 
 <br>
<h1><i class="fas fa-plus-circle"></i><i class="fas fa-chalkboard-teacher"></i>  Registro Grado</h1>
<hr>
<div class=alert><?php echo isset($alert)? $alert : ''; ?></div>


<form action="" method="post">
<label for="grado">GRADO</label>
<input type="text" name="grado" id="grado" placeholder="Ingrese el grado">
<label for="grado">GRUPO</label>
<select name="grupo" id = "grupo">
<option value="A">A</option>
  <option value="B" >B</option>
  <option value="C">C</option>
</select>


<button type="submit" class="btn_save"><i class="far fa-save"></i> Crear Grado</button>


</form>

    </section>
  
</body>
</html>
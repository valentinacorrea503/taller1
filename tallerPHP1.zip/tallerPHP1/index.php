<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Colegio</title>

	<nav>
		<ul>
				<li><a href="index.php"><i class="fas fa-home"></i> Inicio  </a></li>
				<li class="principal">
				
					<a href="#"><i class="fas fa-user-graduate"></i> Estudiantes </a>
					  
					<ul>
               
						<li><a href="crear_estudiante.php"><i class="fas fa-user-plus"></i> Nuevo Estudiante</a></li>

                        <li><a href="lista_estudiante.php"><i class="fas fa-users"></i> Lista de Estudiantes</a></li>
	             
					
					</ul>
				</li>
			
               <li class="principal">
			
					<a href="#"><i class="fas fa-chalkboard-teacher"></i> Grados </a>
					<ul>

						<li><a href="crear_grado.php">Registro de Grado</a></li>
						<li><a href="grados.php">lista de Grados</a></li>

						
					</ul>
				</li>
								 
	</nav>
</head>
<body>

</body>
</html>
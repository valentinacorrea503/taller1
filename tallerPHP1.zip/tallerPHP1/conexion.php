<?php
//conexion a la base de datos
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'colegio';

$conection = @mysqli_connect($host,$user,$password,$db);
$conection -> set_charset("utf8");


if(!$conection){
    echo "ERROR EN LA CONEXION";
}
?>
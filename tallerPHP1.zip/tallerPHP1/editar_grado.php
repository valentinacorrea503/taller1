<?php


  include "conexion.php";

if(!empty($_POST)){
  $alert='';
 if(empty($_POST['grado'])|| empty($_POST['grupo']))   
  {
  $alert='<p class="msg_error"> todos los campos son obligatorios.</p>';

  }else{
     $idgrado = $_POST['id'];
    $grado = $_POST['grado'];
     $grupo = $_POST['grupo'];
     
   
   
    
 $query = mysqli_query($conection,"SELECT * FROM grado WHERE grado = '$grado' and grupo = '$grupo' and ID != $idgrado  and estatus = 1" );
        
        $result = mysqli_fetch_array($query);

        if($result > 0){
            $alert ='<p class="msg_error">El  GRADO_GRUPO YA EXISTE  .</p>';

    }else{




        $sql_update = mysqli_query($conection, "UPDATE grado
                            SET 
                                grado='$grado',
                                grupo='$grupo'
                            WHERE ID= '$idgrado' ");

    if($sql_update){

      $alert ='<p class="msg_save">Grado actualizado correctamente.</p>';
    }else{
      $alert ='<p class="msg_error">Error al actualizar el Grado.</p>';
    }
    }

    
  }
}
  
  


//mostrar datos
if(empty($_REQUEST['id'])){
  header('location: grados.php');
  mysqli_close($conection);
}
$idgrado = $_REQUEST['id'];
$sql=mysqli_query($conection,"SELECT *
                                FROM grado g
                WHERE ID= $idgrado AND g.estatus = 1");

mysqli_close($conection);

$result_sql=mysqli_num_rows($sql);
 
 if ($result_sql > 0){
        $data = mysqli_fetch_assoc($sql);

}else{
        header("location: grados.php"); 
    }
           
 
           
 
           
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
<?php include "index.php"?>
  <title>actualizar Grado</title>
</head>
<body>
  <section id="container">
  
<div class="form_register"> 
  <br>
<h1><i class="far fa-edit"></i> Actualizar Grado</h1>
<hr>
<div class=alert><?php echo isset($alert)? $alert : ''; ?></div>


<form action="" method="post">
<input type="hidden" name="id" value="<?php echo $idgrado; ?>">

<label for="grado">GRADO</label>
<input type="text" name="grado" id="grado" placeholder="Grado" value="<?php echo $data['grado']; ?>">



<label for="grupo">Grupo</label>

<?php 
include "conexion.php";
$query_grupo = mysqli_query($conection, "SELECT * FROM grado");
mysqli_close($conection);
$result_grupo = mysqli_num_rows($query_grupo);

?>

<select name="grupo" id = "grupo" class="notItemOne">
<option value="<?php echo $data['grupo']; ?>" selected><?php echo $data['grupo']; ?></option>
<option value="A">A</option>
  <option value="B" >B</option>
  <option value="C">C</option>
</select>


<button type="submit" class="btn_save"><i class="far fa-edit">Actualizar Grado</i></button>

</form>
</div>

  </section>

</body>
</html>
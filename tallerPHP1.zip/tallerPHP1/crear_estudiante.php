<?php

session_start();


  include "conexion.php";

if(!empty($_POST)){
  $alert='';
 if(empty($_POST['identificacion']) || empty($_POST['nombre'])  || empty($_POST['fecha_nacimiento']) || empty($_POST['edad']) || empty($_POST['peso']) || empty($_POST['correo']) || empty($_POST['grado']))   
  {
  $alert='<p class="msg_error"> todos los campos son obligatorios.</p>';

  }else{
  
   
    $identificacion = $_POST['identificacion'];
    $nombre = $_POST['nombre'];
    $fechaNacimiento = $_POST['fecha_nacimiento'];
    $edad = $_POST['edad'];
    $peso = $_POST['peso'];
    $correo = $_POST['correo'];
     $grado = $_POST['grado'];
    
      



        $query = mysqli_query($conection,"SELECT * FROM estudiante WHERE identificacion = '$identificacion'");
  
    $result = mysqli_fetch_array($query);

        if($result > 0){
      $alert ='<p class="msg_error">El  numero de Identificacion ya existe.</p>';

    }else{ 
     
     $query_insert = mysqli_query($conection, "INSERT INTO estudiante(identificacion,nombre,fechaNacimiento,edad,peso,correo,idGrado)
            VALUES('$identificacion','$nombre','$fechaNacimiento','$edad','$peso','$correo','$grado')");
    if($query_insert){
      
      $alert ='<p class="msg_save">Estudiante creado correctamente.</p>';
    }else{
      $alert ='<p class="msg_error">Error al crear el Estudiante.</p>';
    }

    }

}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
<?php include "index.php"?>
  <title>Registro Estudiante</title>
</head>
<body>

  <section id="container">
  
<div class="form_register"> 

<h1> <i class="fas fa-user-plus"></i>  Registro Estudiante</h1>
<hr>
<div class=alert><?php echo isset($alert)? $alert : ''; ?></div>


<form action="" method="post" enctype="multipart/form-data">
<form action="" method="post">
<label for="Identificacion">Indetificacion</label>
<input type="number" name="identificacion" id="identificacion" placeholder="Identificacion del estudiante">

<label for="nombre">Nombres</label>
<input type="text" name="nombre" id="nombre" placeholder="Digite nombres y apellidos">

<label for="fecha_nacimiento">Fecha de Nacimiento</label>
<input type="date" name="fecha_nacimiento" id="fecha_nacimiento" placeholder="fecha_nacimiento">

<label for="edad">Edad</label>
<input type="number" name="edad" id="edad" placeholder="edad">

<label for="peso">Peso</label>
<input type="number" step="0.01" name="peso" id="peso" placeholder="Digite el peso en kg">

<label for="correo">Correo</label>
<input type="text" name="correo" id="correo" placeholder="Correo electronico">
 
<label for="grado">Grado del estudiante</label>

<?php 
$query_grado = mysqli_query($conection, "SELECT DISTINCT * FROM grado
WHERE estatus = 1");

$result_grado = mysqli_num_rows($query_grado);

?>

<select name="grado" id = "grado">
<?php
if($result_grado > 0)
{
  while ($grado=mysqli_fetch_array($query_grado)){
  ?>
    <option value="<?php echo $grado["ID"]; ?>"><?php echo $grado["grado"] ?></option>
  <?php
  }
  }
?>


</select>


<button type="submit" class="btn_save"><i class="far fa-save"></i> Crear Estudiante</button>

</form>

  </section>

</body>
</html>


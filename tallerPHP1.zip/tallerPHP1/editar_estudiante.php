<?php

  include "conexion.php";

if(!empty($_POST)){
  $alert='';
 if(empty($_POST['identificacion']) || empty($_POST['nombre'])  || empty($_POST['fecha_nacimiento']) || empty($_POST['edad']) || empty($_POST['peso']) || empty($_POST['correo']) || empty($_POST['grado']))   
  {
  $alert='<p class="msg_error"> todos los campos son obligatorios.</p>';

  }else{
  
   $codigo = $_POST['id'];
     $identificacion = $_POST['identificacion'];
    $nombre = $_POST['nombre'];
    $fechaNacimiento = $_POST['fecha_nacimiento'];
    $edad = $_POST['edad'];
    $peso = $_POST['peso'];
    $correo = $_POST['correo'];
     $grado = $_POST['grado'];
    
 



    $query = mysqli_query($conection,"SELECT * FROM estudiante
                    WHERE (identificacion = '$identificacion' AND ID != $codigo)");


    $result = mysqli_fetch_array($query);
  

        if($result > 0){
      $alert ='<p class="msg_error">El numero de identificacion ya existe.</p>';

    }else{
        $sql_update = mysqli_query($conection, "UPDATE estudiante
                            SET identificacion ='$identificacion',
                                nombre ='$nombre',
                                fechaNacimiento='$fechaNacimiento',
                                edad='$edad',
                                 peso='$peso',
                                correo='$correo',
                                idGrado='$grado'
                                WHERE ID='$codigo'");

         if($sql_update){


        $alert ='<p class="msg_save">Estudiante actualizado correctamente.</p>';
    }else{
      $alert ='<p class="msg_error">Error al actualizar el Estudiante.</p>';
    }

      }  

  }
  
}

//mostrar datos
if(empty($_REQUEST['id'])){
  header('location: lista_estudiante.php');
  mysqli_close($conection);
}
$cod = $_REQUEST['id'];
$sql=mysqli_query($conection,"SELECT  e.ID, e.identificacion, e.nombre, e.fechaRegistro, e.fechaNacimiento, e.edad, e.peso, e.correo, g.grado FROM estudiante e
  INNER JOIN grado g ON g.ID = e.idGrado
         WHERE e.ID = $cod ");

mysqli_close($conection);

 $result_sql=mysqli_num_rows($sql);
 
 if ($result_sql > 0){
        $data_estudiante = mysqli_fetch_assoc($sql);

    }else{
       header("location: ./");
    }
           
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
<?php include "index.php"?>
  <title>actualizar Estudiante</title>
</head>
<body>

  <section id="container">
  
<div class="form_register"> 
  <br>
<h1><i class="far fa-edit"></i> Actualizar Estudiante</h1>
<hr>
<div class=alert><?php echo isset($alert)? $alert : ''; ?></div>

<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $data_estudiante['ID']; ?>">

<input type="hidden" name="id" value="<?php echo $cod; ?>">
<label for="identificacion">Identificacion</label>
<input type="number" name="identificacion" id="identificacion" placeholder="Identificacion" value="<?php echo $data_estudiante['identificacion']; ?>">

<label for="nombre">Nombre</label>
<input type="text" name="nombre" id="nombre" placeholder="Nombre" value="<?php echo $data_estudiante['nombre']; ?>">

<label for="fecha_nacimiento">Feche De Nacimiento</label>
<input type="date" name="fecha_nacimiento" id="fecha_nacimiento" placeholder="fecha_nacimiento" value="<?php echo $data_estudiante['fechaNacimiento'];?>">

<label for="edad">Edad</label>
<input type="number" name="edad" id="edad" placeholder="edad" value="<?php echo $data_estudiante['edad']; ?>">

<label for="peso">Peso</label>
<input type="number" name="peso" id="peso" placeholder="peso" value="<?php echo $data_estudiante['peso']; ?>">

<label for="correo">Correo electronico</label>
<input type="text" name="correo" id="correo" placeholder="correo" value="<?php echo $data_estudiante['correo']; ?>">



<label for="grado">GRADO</label>

<?php 
include "conexion.php";
$query_grado = mysqli_query($conection, "SELECT DISTINCT * FROM grado

WHERE estatus = 1");
mysqli_close($conection);
$result_grado = mysqli_num_rows($query_grado);

?>

<select name="grado" id = "grado" class="notItemOne">
<option value="<?php echo $data_estudiante['grado']; ?>" selected><?php echo $data_estudiante['grado']; ?></option>
<?php
if($result_grado > 0)
{
  while ($grado=mysqli_fetch_array($query_grado)){
  ?>
    <option value="<?php echo $grado["ID"]; ?>"><?php echo $grado["grado"] ?></option>
  <?php
  }
  }
?>


</select>


<button type="submit" class="btn_save"><i class="far fa-edit">Actualizar Estudiante</i></button>

</form>
</div>

  </section>
</body>
</html>
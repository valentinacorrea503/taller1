<?php

   include "conexion.php";


if(!empty($_POST))
{


    if(empty($_POST['idgrado'])){


  header("location: grados.php");   
  mysqli_close($conection);

    }
$idgrado = $_POST['idgrado'];

//$query_delete = mysqli_query($conection,"DELETE FROM usuario WHERE idusuario=$idusuario");
$query_delete = mysqli_query($conection, "UPDATE grado SET estatus = 0 WHERE ID = $idgrado");
mysqli_close($conection);
if($query_delete){
    header("location: grados.php");

}else{
    echo "Error al eliminar";
}

}



if(empty($_REQUEST['id']))
{
header("location: grados.php");
mysqli_close($conection);
}else{
 
    $idgrado = $_REQUEST['id'];

    $query = mysqli_query($conection,"SELECT * FROM grado
                                            WHERE ID = $idgrado");
                
    mysqli_close($conection);
     
                $result = mysqli_num_rows($query);
      if ($result > 0){  
      while($data = mysqli_fetch_array($query)){

        $grado = $data['grado'];
        $grupo = $data['grupo'];
        

              }
          } else{
              header("location: grados.php");

          }     
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "index.php"?>
	<title>Eliminar grado</title>
</head>
<body>

	<section id="container">
	<div class="data_delete">
    <i class="fas fa-user-times fa-7x" style="color: #e66262"></i>
<br>
<br>
    <h2>¿está seguro de eliminar el siguiente registro?</h2>
    <p>Grado: <span><?php echo $grado; ?></span></p>
     <p>Grupo: <span><?php echo $grupo; ?></span></p>
    
    

    <form method="post" action="">
        <input type = "hidden" name = "idgrado" value="<?php echo $idgrado; ?>">
    <a href= "grados.php" class="btn_cancel"><i class="fas fa-ban"></i> Cancelar</a>
     <button type="submit" class="btn_ok"><i class="fas fa-trash-alt fa-lg"></i> Eliminar</button>
    </form>
    </div>
    
    
	</section>
	
</body>
</html>
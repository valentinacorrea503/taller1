<?php


include "conexion.php";


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
<?php include "index.php"?>
  <title>Lista de Estudiantes</title>

  
</head>
<body>

  <section id="container">
 
   

    <h1><i class="fas fa-users fa-lg"></i>  Lista de Estudiantes</h1>
        <a href="crear_estudiante.php" class="btn_new"> <i class="fas fa-user-plus"></i> Crear Estudiante</a>
       





<div class="containerTable">
<table>
<tr>

<th>ID</th>
<th>identificacion</th>
<th>Nombres</th>
<th>Fecha de Registro</th>
<th>Fecha de Nacimiento</th>
<th>Edad</th>
<th>Peso (kg)</th>
<th>Correo</th>
<th>Grado</th>
<th>Acciones</th>
</tr>

<?php







$query = mysqli_query($conection, "SELECT e.ID, e.identificacion, e.nombre, e.fechaRegistro, e.fechaNacimiento, e.edad, e.peso, e.correo, g.grado FROM estudiante e
  INNER JOIN grado g ON g.ID = e.idGrado
ORDER BY g.ID desc");

mysqli_close($conection);

$result = mysqli_num_rows($query);
if($result > 0){

  while ($data = mysqli_fetch_array($query)) {

  

?>
<tr>

<td><?php echo $data ["ID"]; ?></td>
<td><?php echo $data ["identificacion"]; ?></td>
<td><?php echo $data ["nombre"]; ?></td>
<td><?php echo $data ["fechaRegistro"]; ?></td>
<td><?php echo $data ["fechaNacimiento"]; ?></td>
<td><?php echo $data ["edad"]; ?></td>
<td><?php echo $data ["peso"]; ?></td>
<td><?php echo $data ["correo"]; ?></td>
<td><?php echo $data ["grado"]; ?></td>

<td>

<a class="link_edit" href="editar_estudiante.php?id=<?php echo $data ["ID"];
 ?>"><i class="far fa-edit"></i> Editar</a>
 

|
<a class="link_delete" href="#"><i class="fas fa-trash-alt"></i> Eliminar</a>
 
</td>
</tr>

<?php   
  }
}

?>

</table>
</td>
  </section>
 
</body>
</html>
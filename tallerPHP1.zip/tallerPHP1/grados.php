<?php

include "conexion.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "index.php"?>
	<title>Lista de Grados</title>
</head>
<body>

	<section id="container">
<br>
		<h1><i class="far fa-file-alt"></i><i class="fas fa-chalkboard-teacher"></i>  Lista de Grados</h1>
        <a href="crear_grado.php" class="btn_new"> Crear Grado</a>

<div class="containerTable">
<table>
<tr>
<th>Grado</th>
<th>Grupo</th>
<th>Acciones</th>
</tr>

<?php

$query = mysqli_query($conection, "SELECT * FROM grado WHERE estatus = 1");

mysqli_close($conection);

$result = mysqli_num_rows($query);
if($result > 0){

	while ($data = mysqli_fetch_array($query)) {


?>
<tr>
<td><?php echo $data ["grado"]; ?></td>
<td><?php echo $data ["grupo"]; ?></td>

<td>
<a class="link_edit" href="editar_grado.php?id=<?php echo $data ["ID"];
 ?>"><i class="far fa-edit"></i> Editar</a>
 
 
|
<a class="link_delete" href="eliminar_grado.php?id=<?php echo $data ["ID"];
 ?>"><i class="fas fa-trash-alt"></i> Eliminar</a>

</td>
</tr>

<?php		
	}
}
?>

</table>
</div>



	</section>
	
</body>
</html>